# -*- coding: utf-8 -*-
"""
智慧园区物联网综合管理平台 - 完整后端
支持: Flask Web服务 + MQTT消息队列 + SQLite数据库
"""
import os
import json
import random
import time
import threading
from datetime import datetime, timedelta
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS

# MQTT相关 (可选)
try:
    import paho.mqtt.client as mqtt
    MQTT_ENABLED = True
except ImportError:
    MQTT_ENABLED = False
    print("MQTT库未安装，将使用HTTP轮询模式")

# 数据库相关
import sqlite3

app = Flask(__name__, template_folder='templates')
CORS(app)

# ==================== 数据库初始化 ====================

DB_PATH = os.path.join(os.path.dirname(__file__), '..', 'database', 'park.db')

def init_db():
    """初始化数据库"""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS devices (id INTEGER PRIMARY KEY, device_id TEXT, name TEXT, device_type TEXT, location TEXT, status TEXT, state INTEGER, value REAL, power REAL, last_update TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS sensor_data (id INTEGER PRIMARY KEY, device_id TEXT, sensor_type TEXT, value REAL, unit TEXT, timestamp TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS alerts (id INTEGER PRIMARY KEY, level TEXT, alert_type TEXT, content TEXT, device_id TEXT, status TEXT, timestamp TEXT)''')
    conn.commit()
    conn.close()
    print("数据库初始化完成:", DB_PATH)

# ==================== 数据模型 ====================

class IoTDevice:
    def __init__(self, device_id, name, device_type, location, status='offline'):
        self.device_id = device_id
        self.name = name
        self.device_type = device_type
        self.location = location
        self.status = random.choice(['online', 'online', 'online', 'offline']) if status == 'offline' else status
        self.state = random.choice([True, True, False])
        self.value = 0
        self.power = random.uniform(0.1, 2.0)
        self.last_update = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.online_time = random.randint(1, 720)
        self.error_count = random.randint(0, 3)

class DeviceManager:
    def __init__(self):
        self.devices = {}
        self._init_devices()
    
    def _init_devices(self):
        for i in range(50):
            self.devices[f'light-{i+1:03d}'] = IoTDevice(f'light-{i+1:03d}', f'智能灯-{i+1}', 'light', f'{chr(65+(i//10))}区{i%10+1}栋')
        for i in range(20):
            self.devices[f'ac-{i+1:03d}'] = IoTDevice(f'ac-{i+1:03d}', f'空调-{i+1}', 'ac', f'{chr(65+(i//5))}区{i%5+1}栋')
        for i in range(30):
            self.devices[f'camera-{i+1:03d}'] = IoTDevice(f'camera-{i+1:03d}', f'摄像头-{i+1}', 'camera', f'园区{chr(65+i//10)}区域')
        for i in range(15):
            self.devices[f'door-{i+1:03d}'] = IoTDevice(f'door-{i+1:03d}', f'门禁-{i+1}', 'door', f'{chr(65+i//5)}区入口')
        for i in range(40):
            self.devices[f'sensor-{i+1:03d}'] = IoTDevice(f'sensor-{i+1:03d}', f'环境传感器-{i+1}', 'sensor', f'{chr(65+i//10)}区{i%10+1}栋')
        for i in range(10):
            self.devices[f'elevator-{i+1:03d}'] = IoTDevice(f'elevator-{i+1:03d}', f'电梯-{i+1}', 'elevator', f'{chr(65+i//3)}区{i%3+1}栋')
        print(f"已初始化 {len(self.devices)} 个设备")
    
    def get_all_devices(self):
        return [{'device_id': d.device_id, 'name': d.name, 'device_type': d.device_type, 'location': d.location, 'status': d.status, 'state': d.state, 'value': d.value, 'power': round(d.power, 2), 'last_update': d.last_update, 'online_time': d.online_time, 'error_count': d.error_count} for d in self.devices.values()]
    
    def get_device(self, device_id):
        if device_id in self.devices:
            d = self.devices[device_id]
            return {'device_id': d.device_id, 'name': d.name, 'device_type': d.device_type, 'location': d.location, 'status': d.status, 'state': d.state, 'value': d.value, 'power': round(d.power, 2), 'last_update': d.last_update, 'online_time': d.online_time, 'error_count': d.error_count}
        return None
    
    def toggle_device(self, device_id):
        if device_id in self.devices:
            d = self.devices[device_id]
            d.state = not d.state
            d.last_update = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            return {'device_id': d.device_id, 'name': d.name, 'device_type': d.device_type, 'location': d.location, 'status': d.status, 'state': d.state, 'value': d.value, 'power': round(d.power, 2), 'last_update': d.last_update, 'online_time': d.online_time, 'error_count': d.error_count}
        return None
    
    def get_devices_by_type(self, device_type):
        return [d for d in self.get_all_devices() if d['device_type'] == device_type]
    
    def get_stats(self):
        total = len(self.devices)
        online = sum(1 for d in self.devices.values() if d.status == 'online')
        return {'total_devices': total, 'online_devices': online, 'error_devices': 0, 'running_devices': sum(1 for d in self.devices.values() if d.state), 'online_rate': round(online/total*100, 1) if total>0 else 0}

class EnergyManager:
    def __init__(self):
        self.electricity = random.uniform(800, 1200)
        self.water = random.uniform(200, 400)
        self.gas = random.uniform(50, 100)
    
    def get_energy(self):
        self.electricity += random.uniform(-10, 10)
        dates = [(datetime.now() - timedelta(days=i)).strftime('%m-%d') for i in range(7, 0, -1)]
        return {
            'today': {'electricity': round(self.electricity, 1), 'water': round(self.water, 1), 'gas': round(self.gas, 1)}, 
            'history': {'dates': dates, 'electricity': [round(random.uniform(800, 1200), 1) for _ in range(7)], 'water': [round(random.uniform(200, 400), 1) for _ in range(7)], 'gas': [round(random.uniform(50, 100), 1) for _ in range(7)]},
            'by_type': {'light': {'count': 50, 'power': round(random.uniform(500, 800), 1), 'online': 45}, 'ac': {'count': 20, 'power': round(random.uniform(2000, 3000), 1), 'online': 18}, 'camera': {'count': 30, 'power': round(random.uniform(300, 500), 1), 'online': 28}, 'door': {'count': 15, 'power': round(random.uniform(50, 100), 1), 'online': 14}, 'sensor': {'count': 40, 'power': round(random.uniform(20, 50), 1), 'online': 38}, 'elevator': {'count': 10, 'power': round(random.uniform(500, 800), 1), 'online': 10}}
        }

class EnvironmentMonitor:
    def __init__(self):
        self.temperature = random.uniform(18, 28)
        self.humidity = random.uniform(40, 70)
        self.pm25 = random.uniform(10, 80)
        self.co2 = random.uniform(400, 800)
    
    def get_environment(self):
        self.temperature += random.uniform(-0.5, 0.5)
        self.humidity += random.uniform(-2, 2)
        self.pm25 += random.uniform(-5, 5)
        self.co2 += random.uniform(-20, 20)
        return {
            'temperature': round(max(15, min(35, self.temperature)), 1),
            'humidity': round(max(30, min(80, self.humidity)), 1),
            'pm25': round(max(0, min(150, self.pm25))),
            'co2': round(max(300, min(1000, self.co2))),
            'aqi': round(random.uniform(30, 80), 0),
            'noise': round(random.uniform(40, 70), 0),
            'light': round(random.uniform(1000, 10000), 0)
        }

class SecuritySystem:
    def __init__(self, device_manager):
        self.entries_today = random.randint(500, 2000)
        self.abnormal_events = random.randint(0, 5)
        self.access_history = [random.randint(300, 500) for _ in range(24)]
    
    def get_security(self):
        return {
            'cameras_online': random.randint(25, 30),
            'cameras_total': 30,
            'entries_today': self.entries_today,
            'exits_today': random.randint(400, 1800),
            'abnormal_events': self.abnormal_events,
            'access_history': self.access_history,
            'door_status': {'A区': random.choice(['open', 'closed']), 'B区': random.choice(['open', 'closed']), 'C区': random.choice(['open', 'closed'])},
            'fire_alarms': random.randint(0, 2),
            'intruders': random.randint(0, 1)
        }

class AlertSystem:
    def __init__(self):
        self.alerts = [
            {'time': '14:32', 'level': '中', 'type': '设备', 'content': '空调设备温度过高', 'device': 'ac-005', 'status': '处理中'},
            {'time': '13:15', 'level': '低', 'type': '能耗', 'content': 'C区用电量异常', 'device': '总配电箱', 'status': '已处理'},
            {'time': '11:20', 'level': '高', 'type': '安防', 'content': '检测到未授权进入', 'device': 'camera-012', 'status': '待处理'},
            {'time': '10:05', 'level': '中', 'type': '环境', 'content': 'PM2.5超标', 'device': 'sensor-008', 'status': '已处理'},
            {'time': '09:30', 'level': '低', 'type': '设备', 'content': '门禁通讯异常', 'device': 'door-003', 'status': '已处理'},
            {'time': '08:45', 'level': '中', 'type': '安防', 'content': '周界报警触发', 'device': 'camera-018', 'status': '已处理'},
            {'time': '08:00', 'level': '低', 'type': '环境', 'content': 'CO2浓度偏高', 'device': 'sensor-015', 'status': '已处理'},
            {'time': '07:30', 'level': '高', 'type': '设备', 'content': '电梯故障', 'device': 'elevator-002', 'status': '处理中'}
        ]
    
    def get_alerts(self):
        return self.alerts

# ==================== 初始化 ====================

init_db()
device_manager = DeviceManager()
energy_manager = EnergyManager()
environment_monitor = EnvironmentMonitor()
security_system = SecuritySystem(device_manager)
alert_system = AlertSystem()

# ==================== 路由 ====================

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/index.html')
def index_html():
    return render_template('index.html')

@app.route('/devices.html')
def devices():
    return render_template('devices.html')

@app.route('/energy.html')
def energy():
    return render_template('energy.html')

@app.route('/environment.html')
def environment():
    return render_template('environment.html')

@app.route('/security.html')
def security():
    return render_template('security.html')

@app.route('/alerts.html')
def alerts():
    return render_template('alerts.html')

# API路由
@app.route('/api/devices')
def api_devices():
    device_type = request.args.get('type')
    if device_type:
        return jsonify(device_manager.get_devices_by_type(device_type))
    return jsonify(device_manager.get_all_devices())

@app.route('/api/device/<device_id>')
def api_device(device_id):
    device = device_manager.get_device(device_id)
    if device:
        return jsonify(device)
    return jsonify({'error': 'Device not found'}), 404

@app.route('/api/device/<device_id>/toggle', methods=['POST'])
def api_device_toggle(device_id):
    device = device_manager.toggle_device(device_id)
    if device:
        return jsonify({'success': True, 'device': device})
    return jsonify({'success': False, 'error': 'Device not found'}), 404

@app.route('/api/energy')
def api_energy():
    return jsonify(energy_manager.get_energy())

@app.route('/api/environment')
def api_environment():
    return jsonify(environment_monitor.get_environment())

@app.route('/api/security')
def api_security():
    return jsonify(security_system.get_security())

@app.route('/api/alerts')
def api_alerts():
    return jsonify(alert_system.get_alerts())

@app.route('/api/overview')
def api_overview():
    stats = device_manager.get_stats()
    stats['entries_today'] = security_system.entries_today
    stats['today_alerts'] = len(alert_system.get_alerts())
    return jsonify(stats)

# ==================== 启动 ====================

if __name__ == '__main__':
    print("=" * 60)
    print("  智慧园区物联网综合管理平台")
    print("=" * 60)
    print(f"  设备总数: {len(device_manager.devices)}")
    print(f"  访问地址: http://localhost:5000")
    print("=" * 60)
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
