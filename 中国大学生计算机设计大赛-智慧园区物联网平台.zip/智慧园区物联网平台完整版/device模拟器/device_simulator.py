# -*- coding: utf-8 -*-
"""
物联网设备模拟器
模拟各种传感器和设备，通过MQTT协议发送数据
"""
import json
import random
import time
import threading
from datetime import datetime

# MQTT库
try:
    import paho.mqtt.client as mqtt
    MQTT_AVAILABLE = True
except ImportError:
    MQTT_AVAILABLE = False
    print("警告: 未安装MQTT库，请运行: pip install paho-mqtt")
    print("模拟器将使用HTTP模式运行")

# MQTT配置
MQTT_BROKER = "localhost"
MQTT_PORT = 1883
MQTT_TOPIC_PREFIX = "park"

class DeviceSimulator:
    """设备模拟器基类"""
    def __init__(self, device_id, name, device_type):
        self.device_id = device_id
        self.name = name
        self.device_type = device_type
        self.status = "online"
        self.value = 0
        self.state = False
    
    def get_data(self):
        """获取设备数据，子类实现"""
        return {}
    
    def publish(self, client, topic, data):
        """发布数据"""
        if client:
            client.publish(topic, json.dumps(data))
    
    def simulate(self, client=None):
        """模拟设备运行"""
        data = self.get_data()
        data['device_id'] = self.device_id
        data['name'] = self.name
        data['device_type'] = self.device_type
        data['status'] = self.status
        data['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        topic = f"{MQTT_TOPIC_PREFIX}/data/{self.device_id}"
        self.publish(client, topic, data)
        return data


class LightSimulator(DeviceSimulator):
    """智能灯模拟器"""
    def __init__(self, device_id, name, location):
        super().__init__(device_id, name, 'light')
        self.location = location
        self.brightness = 0  # 亮度 0-100
        self.color_temp = 4000  # 色温
    
    def get_data(self):
        self.state = random.choice([True, True, True, False])
        self.brightness = random.randint(0, 100) if self.state else 0
        return {
            'type': 'light',
            'state': self.state,
            'brightness': self.brightness,
            'color_temp': self.color_temp,
            'power': self.brightness * 0.1  # 功率
        }


class ACSimulator(DeviceSimulator):
    """空调模拟器"""
    def __init__(self, device_id, name, location):
        super().__init__(device_id, name, 'ac')
        self.location = location
        self.temperature = 24
        self.mode = 'cool'  # cool, heat, auto
        self.fan_speed = 'auto'
    
    def get_data(self):
        self.state = random.choice([True, True, False])
        if self.state:
            self.temperature = random.uniform(20, 28)
        return {
            'type': 'ac',
            'state': self.state,
            'temperature': round(self.temperature, 1),
            'mode': self.mode,
            'fan_speed': self.fan_speed,
            'power': random.uniform(0.5, 2.0) if self.state else 0
        }


class CameraSimulator(DeviceSimulator):
    """摄像头模拟器"""
    def __init__(self, device_id, name, location):
        super().__init__(device_id, name, 'camera')
        self.location = location
        self.status = random.choice(['online', 'online', 'online', 'error'])
        self.resolution = '1080P'
        self.fps = 30
    
    def get_data(self):
        return {
            'type': 'camera',
            'status': self.status,
            'resolution': self.resolution,
            'fps': self.fps,
            'bitrate': random.randint(1000, 4000),
            'power': random.uniform(5, 15)
        }


class DoorSimulator(DeviceSimulator):
    """门禁模拟器"""
    def __init__(self, device_id, name, location):
        super().__init__(device_id, name, 'door')
        self.location = location
        self.status = 'online'
        self.is_open = False
    
    def get_data(self):
        self.is_open = random.choice([False, False, True])
        return {
            'type': 'door',
            'status': self.status,
            'is_open': self.is_open,
            'card_reads': random.randint(0, 100),
            'face_recognitions': random.randint(0, 50),
            'power': random.uniform(2, 5)
        }


class SensorSimulator(DeviceSimulator):
    """环境传感器模拟器"""
    def __init__(self, device_id, name, location):
        super().__init__(device_id, name, 'sensor')
        self.location = location
        self.temperature = random.uniform(18, 28)
        self.humidity = random.uniform(40, 70)
        self.pm25 = random.uniform(10, 80)
    
    def get_data(self):
        # 添加随机波动
        self.temperature += random.uniform(-0.5, 0.5)
        self.humidity += random.uniform(-2, 2)
        self.pm25 += random.uniform(-5, 5)
        
        # 限制范围
        self.temperature = max(10, min(40, self.temperature))
        self.humidity = max(20, min(90, self.humidity))
        self.pm25 = max(0, min(200, self.pm25))
        
        return {
            'type': 'sensor',
            'temperature': round(self.temperature, 1),
            'humidity': round(self.humidity, 1),
            'pm25': round(self.pm25, 1),
            'co2': random.randint(400, 800),
            'light': random.randint(0, 10000),
            'power': random.uniform(0.1, 0.5)
        }


class ElevatorSimulator(DeviceSimulator):
    """电梯模拟器"""
    def __init__(self, device_id, name, location):
        super().__init__(device_id, name, 'elevator')
        self.location = location
        self.current_floor = random.randint(1, 20)
        self.target_floor = random.randint(1, 20)
        self.direction = 'up' if self.target_floor > self.current_floor else 'down'
        self.status = 'running' if self.current_floor != self.target_floor else 'idle'
    
    def get_data(self):
        if self.status == 'running':
            if self.direction == 'up':
                self.current_floor = min(20, self.current_floor + 1)
            else:
                self.current_floor = max(1, self.current_floor - 1)
            
            if self.current_floor == self.target_floor:
                self.status = 'idle'
                self.target_floor = random.randint(1, 20)
                self.direction = 'up' if self.target_floor > self.current_floor else 'down'
        
        return {
            'type': 'elevator',
            'status': self.status,
            'current_floor': self.current_floor,
            'target_floor': self.target_floor,
            'direction': self.direction,
            'passengers': random.randint(0, 10),
            'power': random.uniform(10, 30) if self.status == 'running' else 0.5
        }


class DeviceSimulatorManager:
    """设备模拟器管理器"""
    def __init__(self):
        self.devices = []
        self.mqtt_client = None
        self.running = False
        self._init_devices()
    
    def _init_devices(self):
        """初始化设备"""
        # 智能灯
        for i in range(50):
            self.devices.append(LightSimulator(
                f'light-{i+1:03d}',
                f'智能灯-{i+1}',
                f'{chr(65+(i//10))}区{i%10+1}栋'
            ))
        
        # 空调
        for i in range(20):
            self.devices.append(ACSimulator(
                f'ac-{i+1:03d}',
                f'空调-{i+1}',
                f'{chr(65+(i//5))}区{i%5+1}栋'
            ))
        
        # 摄像头
        for i in range(30):
            self.devices.append(CameraSimulator(
                f'camera-{i+1:03d}',
                f'摄像头-{i+1}',
                f'园区{chr(65+i//10)}区域'
            ))
        
        # 门禁
        for i in range(15):
            self.devices.append(DoorSimulator(
                f'door-{i+1:03d}',
                f'门禁-{i+1}',
                f'{chr(65+i//5)}区入口'
            ))
        
        # 传感器
        for i in range(40):
            self.devices.append(SensorSimulator(
                f'sensor-{i+1:03d}',
                f'环境传感器-{i+1}',
                f'{chr(65+i//10)}区{i%10+1}栋'
            ))
        
        # 电梯
        for i in range(10):
            self.devices.append(ElevatorSimulator(
                f'elevator-{i+1:03d}',
                f'电梯-{i+1}',
                f'{chr(65+i//3)}区{i%3+1}栋'
            ))
        
        print(f"已创建 {len(self.devices)} 个模拟设备")
    
    def connect_mqtt(self):
        """连接MQTT服务器"""
        if not MQTT_AVAILABLE:
            return None
        
        try:
            client = mqtt.Client(client_id="device_simulator")
            client.connect(MQTT_BROKER, MQTT_PORT, 60)
            print(f"已连接到MQTT服务器: {MQTT_BROKER}:{MQTT_PORT}")
            return client
        except Exception as e:
            print(f"MQTT连接失败: {e}")
            return None
    
    def simulate_all(self, client=None):
        """模拟所有设备"""
        for device in self.devices:
            try:
                device.simulate(client)
            except Exception as e:
                print(f"设备 {device.device_id} 模拟失败: {e}")
    
    def start(self, interval=5):
        """启动模拟器"""
        self.running = True
        
        if MQTT_AVAILABLE:
            self.mqtt_client = self.connect_mqtt()
        
        def run():
            while self.running:
                self.simulate_all(self.mqtt_client)
                print(f"[{datetime.now().strftime('%H:%M:%S')}] 已模拟 {len(self.devices)} 个设备")
                time.sleep(interval)
        
        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        print(f"模拟器已启动，每 {interval} 秒更新一次数据")
        
        return thread


def main():
    """主函数"""
    print("=" * 50)
    print("  物联网设备模拟器")
    print("=" * 50)
    print(f" MQTT: {'可用' if MQTT_AVAILABLE else '不可用'}")
    print(f" 目标服务器: {MQTT_BROKER}:{MQTT_PORT}")
    print("=" * 50)
    
    manager = DeviceSimulatorManager()
    
    # 启动模拟器
    try:
        manager.start(interval=5)  # 每5秒更新一次
        
        # 保持运行
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n模拟器已停止")
        if manager.mqtt_client:
            manager.mqtt_client.disconnect()


if __name__ == '__main__':
    main()
